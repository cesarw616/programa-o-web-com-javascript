`use strict`;

let num = Number(prompt('Digite um número: '));
let quad = num**2;
console.log(+(quad));
