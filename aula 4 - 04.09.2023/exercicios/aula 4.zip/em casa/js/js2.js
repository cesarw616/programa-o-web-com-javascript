'use strict';

let nome = prompt('Digite seu nome: ')
document.getElementById("saida").innerHTML=nome
