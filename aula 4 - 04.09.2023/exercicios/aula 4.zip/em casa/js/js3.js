'use strict';

let num = parseInt(prompt('Digite um numero: '));
let quadrado = num*num;

document.getElementById("saida").innerHTML=quadrado;