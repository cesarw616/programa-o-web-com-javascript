let div = document.querySelector("#cards");

function montaCard(pessoa){
    
}

function pesquisa(p_str){
    
}

for(let pessoa of pessoas){
    montaCard(pessoa);
} 

