let url = "xml/menu.xml";
$.ajax(url)
    .done(function (xml) {
        
    })
    .fail(function () {
        alert("Ocorreu um erro no carregamento");
    });