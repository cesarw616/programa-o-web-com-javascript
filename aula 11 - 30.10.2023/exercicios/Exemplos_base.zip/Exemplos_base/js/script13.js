$("#btn").click(function () {
    let r = $("#rgm").val();
    buscarRgm(r);
}); 

function buscarRgm(rgm) {
    
}
