let url = "https://randomuser.me/api/?format=json&results=10";

