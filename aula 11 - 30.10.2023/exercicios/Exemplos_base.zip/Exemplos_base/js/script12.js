let base;

$(function () {
    $("#btn1").click(cadastrarDados);
    $("#btn2").click(listarDados);
});

function cadastrarDados() {
    
}

function listarDados() {
    
}