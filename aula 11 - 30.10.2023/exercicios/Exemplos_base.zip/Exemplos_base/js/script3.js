function carregaJSON(url){	
    criaObjetoXHR();      
    xhr.open('GET', url, true); 
    xhr.responseType = 'json';
    xhr.withCredentials = true;
    xhr.send(null);
    xhr.onload = function() {
        exibir(xhr.response);
    };   
}

function exibir(json){
          
}

carregaJSON("json/dados.json");