$.getJSON("json/dados.json",function(data){
    console.log(data);
    for (let opc of data.opcoes){
        $('#menu').append(`${opc.id} - ${opc.nome}<br>`);
    }
})