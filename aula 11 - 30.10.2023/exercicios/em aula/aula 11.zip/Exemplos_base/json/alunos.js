let alunos = [
    {
        "rgm": "123456-0",
        "nome": "Fulano",
        "idade": 22
    },
    {
        "rgm": "988985-7",
        "nome": "Beltrano",
        "idade": 30
    },
    {
        "rgm": "232323-4",
        "nome": "Ciclano",
        "idade": 25
    },
    {
        "rgm": "444444-4",
        "nome": "Corona",
        "idade": 21
    }
]